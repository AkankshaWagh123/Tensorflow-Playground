import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

st.header('Heading')

# Generate some sample data
np.random.seed(0)
fv = np.random.randn(100, 2)
cv = np.random.randint(0, 2, 100)

# Create a scatter plot
fig_data, ax = plt.subplots(figsize=(8, 8), constrained_layout=True)
sns.scatterplot(x=fv[:, 0], y=fv[:, 1], hue=cv, ax=ax)
st.pyplot(fig_data)

# Create a container layout
with st.container():
    # Define column widths
    coli, col2, col3 = st.columns([5, 2, 5])
    
    with coli:
        st.header("Data")
        st.pyplot(fig_data)
    
    with col3:
        st.header('Decision Boundary')

