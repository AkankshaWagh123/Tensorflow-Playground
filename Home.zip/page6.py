import streamlit as st
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from keras.models import Sequential
from keras.layers import Dense
from contextlib import redirect_stdout
import io  
import matplotlib.pyplot as plt
from mlxtend.plotting import plot_decision_regions

# Define the file paths to the datasets
dataset_files = {
    "U Shape": "C:/Users/Akanksha/Downloads/1.ushape.csv",
    "Concentric Circle 1": "C:/Users/Akanksha/Downloads/2.concerticcir1.csv",
    "Concentric Circle 2": "C:/Users/Akanksha/Downloads/3.concertriccir2.csv",
    "Linearly Separable": "C:/Users/Akanksha/Downloads/4.linearsep.csv",
    "Outliers": "C:/Users/Akanksha/Downloads/5.outlier.csv",
    "Overlap": "C:/Users/Akanksha/Downloads/6.overlap.csv",
    "XOR": "C:/Users/Akanksha/Downloads/7.xor.csv",
    "Two Spirals": "C:/Users/Akanksha/Downloads/8.twospirals.csv",
    "Random": "C:/Users/Akanksha/Downloads/9.random.csv"
}

num_layers = st.number_input("Number of Hidden Layers", value=0)
neurons_inputs = []
if num_layers:
    for i in range(num_layers):
        neurons_input = st.number_input(f"Number of neurons in Hidden Layer {i+1}", value=0)
        neurons_inputs.append(neurons_input)

activation = st.sidebar.selectbox("Activation Function", ["sigmoid", "tanh", "relu"])
epochs = st.sidebar.slider("Number of Epochs", min_value=1, max_value=1000, value=10)
selected_dataset = st.sidebar.selectbox("Select Dataset", list(dataset_files.keys()))
batch_size = st.sidebar.slider("Batch Size", min_value=1, max_value=128, value=32)
learning_rate = st.sidebar.slider("Learning Rate", min_value=0.001, max_value=0.1, value=0.01)
submit_button = st.sidebar.button("Submit")

# Execute the following code only if the submit button is clicked
if submit_button:
    # Load the selected dataset
    df = pd.read_csv(dataset_files[selected_dataset])

    # Split the dataset into features and labels
    X = df.iloc[:, :-1].values  # Features
    y = df.iloc[:, -1].values   # Labels

    # Convert labels to binary
    label_encoder = LabelEncoder()
    y_binary = label_encoder.fit_transform(y)

    # Split the dataset into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y_binary, test_size=0.2, random_state=42)

    # Build the model
    model = Sequential()
    model.add(Dense(neurons_inputs[0], activation=activation, input_shape=(X_train.shape[1],)))
    for neurons in neurons_inputs[1:]:
        model.add(Dense(neurons, activation=activation))
    model.add(Dense(1, activation='sigmoid'))

    # Compile the model
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

    # Train the model
    history=model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size,validation_split =0.2, verbose=0)

    # Display training results and model architecture
    st.subheader("Training Results")
    st.write("Number of Epochs:", epochs)
    st.write("Batch Size:", batch_size)
    st.write("Learning Rate:", learning_rate)
    st.write("Model architecture:")
    with io.StringIO() as buffer:
        with redirect_stdout(buffer):
            model.summary()
        model_summary_text = buffer.getvalue().split('\n')
    st.text('\n'.join(model_summary_text))

    # Plot decision regions
    st.subheader("Decision Regions")
    fig, ax = plt.subplots()  # Corrected line
    plot_decision_regions(X_test, y_test, clf=model, legend=2, ax=ax)  # Changed 'plt' to 'ax'
    ax.set_xlabel('Feature 1')  # Changed 'plt' to 'ax'
    ax.set_ylabel('Feature 2')  # Changed 'plt' to 'ax'
    ax.set_title('Decision Regions')  # Changed 'plt' to 'ax'
    st.pyplot(fig)
