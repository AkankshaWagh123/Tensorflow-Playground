import streamlit as st
import numpy as np
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from contextlib import redirect_stdout
import io  
import matplotlib.pyplot as plt
from mlxtend.plotting import plot_decision_regions
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA

num_layers = st.number_input("Number of Hidden Layers", value=0)
neurons_inputs = []
if num_layers:
    for i in range(num_layers):
        neurons_input = st.number_input(f"Number of neurons in Hidden Layer {i+1}", value=0)
        neurons_inputs.append(neurons_input)

# Create a sidebar for neural network parameters
st.sidebar.title("Neural Network Parameters")
num_neurons = []
for i in range(num_layers):
    num_neurons.append(st.sidebar.slider(f"Number of Neurons in Hidden Layer {i+1}", min_value=1, max_value=256, value=64))
activation = st.sidebar.selectbox("Activation Function", ["sigmoid", "tanh", "relu"])
epochs = st.sidebar.slider("Number of Epochs", min_value=1, max_value=1000, value=10)
batch_size = st.sidebar.slider("Batch Size", min_value=1, max_value=128, value=32)
learning_rate = st.sidebar.slider("Learning Rate", min_value=0.001, max_value=0.1, value=0.01)
submit_button = st.sidebar.button("Submit")

# Execute the following code only if the submit button is clicked
if submit_button:
    # Generate some dummy data
    data = np.random.random((1000, 9))  # Adjust the number of features to match your dataset
    labels = np.random.randint(2, size=(1000, 1))

    # Split the dataset into features and labels
    X = data[:, :-1]  # Features
    y = labels[:, -1]  # Labels

    # Convert labels to binary
    label_encoder = LabelEncoder()
    y_binary = label_encoder.fit_transform(y)

    # Split the dataset into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y_binary, test_size=0.2, random_state=42)

    # Perform PCA for dimensionality reduction
    pca = PCA(n_components=2)
    X_train_pca = pca.fit_transform(X_train)
    X_test_pca = pca.transform(X_test)

    # Build the model
    model = Sequential()
    model.add(Dense(num_neurons[0], activation=activation, input_shape=(X_train_pca.shape[1],)))  # Adjust input shape to match the number of features
    for i in range(1, num_layers):
        model.add(Dense(num_neurons[i], activation=activation))
    model.add(Dense(1, activation='sigmoid'))

    # Compile the model
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

    # Train the model
    model.fit(X_train_pca, y_train, epochs=epochs, batch_size=batch_size, validation_split=0.2, verbose=0)

    # Display training results and model architecture
    st.subheader("Training Results")
    st.write("Number of Epochs:", epochs)
    st.write("Model architecture:")
    with io.StringIO() as buffer:
        with redirect_stdout(buffer):
            model.summary()
        model_summary_text = buffer.getvalue().split('\n')
    st.text('\n'.join(model_summary_text))

    # Plot decision regions
    st.subheader("Decision Regions")
    fig, ax = plt.subplots()
    plot_decision_regions(X_test_pca, y_test, clf=model, legend=2, ax=ax)
    ax.set_xlabel('Feature 1')
    ax.set_ylabel('Feature 2')
    ax.set_title('Decision Regions')
    st.pyplot(fig)
