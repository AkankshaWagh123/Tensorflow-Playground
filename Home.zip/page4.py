import streamlit as st
import pandas as pd

# Define data loading functions
def load_dataset_1():
    # Load dataset 1 from file or any other source
    return pd.read_csv(r"C:\Users\Akanksha\Downloads\1.ushape.csv")

def load_dataset_2():
    # Load dataset 2 from file or any other source
    return pd.read_csv(r"C:\Users\Akanksha\Downloads\2.concerticcir1.csv")

def load_dataset_3():
    # Load dataset 2 from file or any other source
    return pd.read_csv(r"C:\Users\Akanksha\Downloads\3.concertriccir2.csv")

def load_dataset_4():
    # Load dataset 2 from file or any other source
    return pd.read_csv(r"C:\Users\Akanksha\Downloads\4.linearsep.csv")

def load_dataset_5():
    # Load dataset 2 from file or any other source
    return pd.read_csv(r"C:\Users\Akanksha\Downloads\5.outlier.csv")

def load_dataset_6():
    # Load dataset 2 from file or any other source
    return pd.read_csv(r"C:\Users\Akanksha\Downloads\6.overlap.csv")

def load_dataset_7():
    # Load dataset 2 from file or any other source
    return pd.read_csv(r"C:\Users\Akanksha\Downloads\7.xor.csv")

def load_dataset_8():
    # Load dataset 2 from file or any other source
    return pd.read_csv(r"C:\Users\Akanksha\Downloads\8.twospirals.csv")

def load_dataset_9():
    # Load dataset 2 from file or any other source
    return pd.read_csv(r"C:\Users\Akanksha\Downloads\9.random.csv")



# Create UI elements
selected_dataset = st.sidebar.selectbox("Select Dataset", ["Dataset 1", "Dataset 2", "Dataset 3", "Dataset 4", "Dataset 5", "Dataset 6", "Dataset 7", "Dataset 8", "Dataset 9"])

# Display selected dataset
if selected_dataset == "Dataset 1":
    dataset = load_dataset_1()
    st.write("### Dataset 1")
    st.write(dataset)
elif selected_dataset == "Dataset 2":
    dataset = load_dataset_2()
    st.write("### Dataset 2")
    st.write(dataset)
elif selected_dataset == "Dataset 3":
    dataset = load_dataset_3()
    st.write("### Dataset 3")
    st.write(dataset)
elif selected_dataset == "Dataset 4":
    dataset = load_dataset_4()
    st.write("### Dataset 4")
    st.write(dataset)
elif selected_dataset == "Dataset 5":
    dataset = load_dataset_5()
    st.write("### Dataset 5")
    st.write(dataset)
elif selected_dataset == "Dataset 6":
    dataset = load_dataset_6()
    st.write("### Dataset 6")
    st.write(dataset)
elif selected_dataset == "Dataset 7":
    dataset = load_dataset_7()
    st.write("### Dataset 7")
    st.write(dataset)
elif selected_dataset == "Dataset 8":
    dataset = load_dataset_8()
    st.write("### Dataset 8")
    st.write(dataset)
elif selected_dataset == "Dataset 9":
    dataset = load_dataset_9()
    st.write("### Dataset 9")
    st.write(dataset)
